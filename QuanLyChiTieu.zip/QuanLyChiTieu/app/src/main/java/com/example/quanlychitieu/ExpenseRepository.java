package com.example.quanlychitieu;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ExpenseRepository {
    private static ExpenseRepository instance;
    private final List<Expense> expenseList;
    private long nextId;

    private ExpenseRepository() {
        expenseList = new ArrayList<>();
        nextId = 1;
        initSampleData();
    }

    public static synchronized ExpenseRepository getInstance() {
        if (instance == null) {
            instance = new ExpenseRepository();
        }
        return instance;
    }

    private void initSampleData() {
        // Initial sample data as specified in requirement
        addExpense(new Expense(0, "Ăn sáng", 30000, "Ăn uống", "12/10/2026", "Bánh mì & cà phê"));
        addExpense(new Expense(0, "Đổ xăng", 50000, "Đi lại", "12/10/2026", "Đổ đầy bình"));
        addExpense(new Expense(0, "Mua sách", 120000, "Học tập", "13/10/2026", "Sách Lập trình Android"));
    }

    public List<Expense> getExpenses() {
        return expenseList;
    }

    public void addExpense(Expense expense) {
        expense.setId(nextId++);
        expenseList.add(expense);
    }

    public boolean deleteExpenseById(long id) {
        return expenseList.removeIf(e -> e.getId() == id);
    }

    public Expense getExpenseById(long id) {
        for (Expense e : expenseList) {
            if (e.getId() == id) {
                return e;
            }
        }
        return null;
    }

    public long getTotalAmount() {
        long total = 0;
        for (Expense e : expenseList) {
            total += e.getAmount();
        }
        return total;
    }

    public static String formatCurrency(long amount) {
        DecimalFormatSymbols symbols = new DecimalFormatSymbols(Locale.getDefault());
        symbols.setGroupingSeparator('.');
        DecimalFormat df = new DecimalFormat("#,### đ", symbols);
        return df.format(amount);
    }
}