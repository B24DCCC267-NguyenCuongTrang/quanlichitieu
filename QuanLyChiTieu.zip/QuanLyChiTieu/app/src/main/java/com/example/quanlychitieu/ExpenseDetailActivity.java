package com.example.quanlychitieu;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ExpenseDetailActivity extends AppCompatActivity {

    private ImageView btnBackHeaderDetail;
    private TextView tvDetailTitle;
    private TextView tvDetailAmount;
    private TextView tvDetailCategory;
    private TextView tvDetailDate;
    private TextView tvDetailNote;
    private Button btnBackDetail;
    private Button btnDeleteExpense;

    private long expenseId;
    private Expense currentExpense;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_expense_detail);

        View mainView = findViewById(R.id.main);
        if (mainView != null) {
            ViewCompat.setOnApplyWindowInsetsListener(mainView, (v, insets) -> {
                Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
                return insets;
            });
        }

        expenseId = getIntent().getLongExtra("EXTRA_EXPENSE_ID", -1);
        currentExpense = ExpenseRepository.getInstance().getExpenseById(expenseId);

        if (currentExpense == null) {
            Toast.makeText(this, "Không tìm thấy khoản chi", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        initViews();
        displayExpenseDetails();
        setupListeners();
    }

    private void initViews() {
        btnBackHeaderDetail = findViewById(R.id.btnBackHeaderDetail);
        tvDetailTitle = findViewById(R.id.tvDetailTitle);
        tvDetailAmount = findViewById(R.id.tvDetailAmount);
        tvDetailCategory = findViewById(R.id.tvDetailCategory);
        tvDetailDate = findViewById(R.id.tvDetailDate);
        tvDetailNote = findViewById(R.id.tvDetailNote);
        btnBackDetail = findViewById(R.id.btnBackDetail);
        btnDeleteExpense = findViewById(R.id.btnDeleteExpense);
    }

    private void displayExpenseDetails() {
        tvDetailTitle.setText(currentExpense.getTitle());
        tvDetailAmount.setText(ExpenseRepository.formatCurrency(currentExpense.getAmount()));
        tvDetailCategory.setText(currentExpense.getCategory());
        tvDetailDate.setText(currentExpense.getDate());

        String note = currentExpense.getNote();
        if (note != null && !note.trim().isEmpty()) {
            tvDetailNote.setText(note);
        } else {
            tvDetailNote.setText(R.string.no_note);
        }
    }

    private void setupListeners() {
        btnBackHeaderDetail.setOnClickListener(v -> finish());
        btnBackDetail.setOnClickListener(v -> finish());

        btnDeleteExpense.setOnClickListener(v -> deleteExpense());
    }

    private void deleteExpense() {
        boolean deleted = ExpenseRepository.getInstance().deleteExpenseById(expenseId);
        if (deleted) {
            Toast.makeText(this, "Đã xóa khoản chi", Toast.LENGTH_SHORT).show();
            setResult(RESULT_OK);
            finish();
        } else {
            Toast.makeText(this, "Không thể xóa khoản chi", Toast.LENGTH_SHORT).show();
        }
    }
}