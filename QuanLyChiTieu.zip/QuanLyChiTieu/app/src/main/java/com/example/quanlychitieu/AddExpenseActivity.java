package com.example.quanlychitieu;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Locale;

public class AddExpenseActivity extends AppCompatActivity {

    private ImageView btnBackHeader;
    private EditText etExpenseName;
    private EditText etExpenseAmount;
    private Spinner spCategory;
    private DatePicker dpExpenseDate;
    private EditText etExpenseNote;
    private Button btnSaveExpense;

    private static final String[] CATEGORIES = {"Ăn uống", "Đi lại", "Học tập", "Giải trí", "Khác"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_expense);

        View mainView = findViewById(R.id.main);
        if (mainView != null) {
            ViewCompat.setOnApplyWindowInsetsListener(mainView, (v, insets) -> {
                Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
                return insets;
            });
        }

        initViews();
        setupCategorySpinner();
        setupListeners();
    }

    private void initViews() {
        btnBackHeader = findViewById(R.id.btnBackHeader);
        etExpenseName = findViewById(R.id.etExpenseName);
        etExpenseAmount = findViewById(R.id.etExpenseAmount);
        spCategory = findViewById(R.id.spCategory);
        dpExpenseDate = findViewById(R.id.dpExpenseDate);
        etExpenseNote = findViewById(R.id.etExpenseNote);
        btnSaveExpense = findViewById(R.id.btnSaveExpense);
    }

    private void setupCategorySpinner() {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                CATEGORIES
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spCategory.setAdapter(adapter);
    }

    private void setupListeners() {
        btnBackHeader.setOnClickListener(v -> finish());
        btnSaveExpense.setOnClickListener(v -> saveExpense());
    }

    private void saveExpense() {
        String name = etExpenseName.getText().toString().trim();
        String amountStr = etExpenseAmount.getText().toString().trim();

        if (name.isEmpty()) {
            etExpenseName.setError(getString(R.string.err_empty_title));
            etExpenseName.requestFocus();
            return;
        }

        long amount;
        try {
            amount = Long.parseLong(amountStr);
        } catch (NumberFormatException e) {
            amount = 0;
        }

        if (amount <= 0) {
            etExpenseAmount.setError(getString(R.string.err_invalid_amount));
            etExpenseAmount.requestFocus();
            return;
        }

        String category = spCategory.getSelectedItem() != null
                ? spCategory.getSelectedItem().toString()
                : CATEGORIES[0];

        int day = dpExpenseDate.getDayOfMonth();
        int month = dpExpenseDate.getMonth() + 1;
        int year = dpExpenseDate.getYear();
        String date = String.format(Locale.getDefault(), "%02d/%02d/%d", day, month, year);

        String note = etExpenseNote.getText().toString().trim();

        Expense expense = new Expense(0, name, amount, category, date, note);
        ExpenseRepository.getInstance().addExpense(expense);

        Toast.makeText(this, "Thêm khoản chi thành công", Toast.LENGTH_SHORT).show();
        setResult(RESULT_OK);
        finish();
    }
}