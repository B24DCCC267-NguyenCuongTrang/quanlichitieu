package com.example.quanlychitieu;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class MainActivity extends AppCompatActivity {

    private TextView tvTotalExpense;
    private RecyclerView rvExpenseList;
    private Button btnAddExpense;

    private ExpenseRepository repository;
    private ExpenseAdapter adapter;

    private final ActivityResultLauncher<Intent> detailOrAddLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                // Refresh list and total when returning from Add or Detail screen
                refreshData();
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        View mainView = findViewById(R.id.main);
        if (mainView != null) {
            ViewCompat.setOnApplyWindowInsetsListener(mainView, (v, insets) -> {
                Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
                return insets;
            });
        }

        repository = ExpenseRepository.getInstance();

        initViews();
        setupRecyclerView();
        setupListeners();
        refreshData();
    }

    private void initViews() {
        tvTotalExpense = findViewById(R.id.tvTotalExpense);
        rvExpenseList = findViewById(R.id.rvExpenseList);
        btnAddExpense = findViewById(R.id.btnAddExpense);
    }

    private void setupRecyclerView() {
        rvExpenseList.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ExpenseAdapter(repository.getExpenses(), expense -> {
            Intent intent = new Intent(MainActivity.this, ExpenseDetailActivity.class);
            intent.putExtra("EXTRA_EXPENSE_ID", expense.getId());
            detailOrAddLauncher.launch(intent);
        });
        rvExpenseList.setAdapter(adapter);
    }

    private void setupListeners() {
        btnAddExpense.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddExpenseActivity.class);
            detailOrAddLauncher.launch(intent);
        });
    }

    private void refreshData() {
        adapter.updateData(repository.getExpenses());
        tvTotalExpense.setText(ExpenseRepository.formatCurrency(repository.getTotalAmount()));
    }
}